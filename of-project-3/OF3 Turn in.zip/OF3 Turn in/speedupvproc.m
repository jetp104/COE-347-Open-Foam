clc;
clear;
% Data
processors = [1, 2, 4, 8, 16, 32, 56];
speedup = [1.000, 2.155, 4.196, 7.96, 13.644, 21.205, 26.985];

% Plot
figure;
plot(processors, speedup, 'o-', 'LineWidth', 2, 'MarkerSize', 8);
xlabel('Number of Processors (P)');
ylabel('Speedup (T(1) / T(P))');
title('Parallel Speedup vs. Number of Processors');
grid on;

% Set axis limits and ticks
xlim([0 60]);
ylim([0 30]);
xticks(0:10:60);
yticks(0:10:30);

% Save as EPS
print('-depsc', 'speedup_plot.eps');

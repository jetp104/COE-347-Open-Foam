clc; 
clear; 

% Load data files
data1 = load('stepFace_p_T.xy');         % Base resolution
data2 = load('stepFace_p_Nx2.xy');       % x2 resolution
data3 = load('stepFace_p_Nx4.xy');       % x4 resolution
data4 = load('stepFace_p_Nx8.xy');       % x4 resolution
data5 = load('stepFace_p_Nx16.xy');       % x4 resolution

% Filter data for y <= 0.2
data1 = data1(data1(:, 2) <= 0.2, :);
data2 = data2(data2(:, 2) <= 0.2, :);
data3 = data3(data3(:, 2) <= 0.2, :);
data4 = data4(data4(:, 2) <= 0.2, :);
data5 = data5(data5(:, 2) <= 0.2, :);

% Extract y and pressure (4th column)
y1 = data1(:, 2); pressure1 = data1(:, 4);
y2 = data2(:, 2); pressure2 = data2(:, 4);
y3 = data3(:, 2); pressure3 = data3(:, 4);
y4 = data4(:, 2); pressure4 = data4(:, 4);
y5 = data5(:, 2); pressure5 = data5(:, 4);

% Plot
figure;
plot(y1, pressure1, 'Color', [0 0.447 0.741], 'LineWidth', 1.5); hold on;   % Dark Blue
plot(y2, pressure2, 'Color', [0.85 0.325 0.098], 'LineWidth', 1.5); hold on;   % Dark Red
plot(y3, pressure3, 'Color', [0.301 0.745 0.933], 'LineWidth', 1.5); hold on;   % black
plot(y4, pressure4, 'Color', [0.466 0.674 0.188], 'LineWidth', 1.5); hold on; % Dark Cyan
plot(y5, pressure5, 'LineStyle', '--', 'Color', [0.494 0.184 0.556], 'LineWidth', 1.5); hold on; % Dark Magenta 

xlabel('y distance (m)');
ylabel('Pressure (Pa)');
title('Pressure vs. y (Step Face)');
legend('Base Resolution', 'x2 Resolution', 'x4 Resolution', 'x8 Resolution', 'x16 Resolution', 'Location', 'best');
grid on;

print('-depsc', 'stepFace.eps');
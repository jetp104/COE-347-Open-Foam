clc; 
clear; 

% Load data files
data1 = load('stepHorizontal_p_T.xy');         % Base resolution
data2 = load('stepHorizontal_p_Nx2.xy');       % x2 resolution
data3 = load('stepHorizontal_p_Nx4.xy');       % x4 resolution
data4 = load('stepHorizontal_p_Nx8.xy');       % x4 resolution
data5 = load('stepHorizontal_p_Nx16.xy');       % x4 resolution

% Filter data for x >= 0.6
data1 = data1(data1(:, 1) >= 0.6, :);
data2 = data2(data2(:, 1) >= 0.6, :);
data3 = data3(data3(:, 1) >= 0.6, :);
data4 = data4(data4(:, 1) >= 0.6, :);
data5 = data5(data5(:, 1) >= 0.6, :);

% Extract x and pressure (4th column)
x1 = data1(:, 1); pressure1 = data1(:, 4);
x2 = data2(:, 1); pressure2 = data2(:, 4);
x3 = data3(:, 1); pressure3 = data3(:, 4);
x4 = data4(:, 1); pressure4 = data4(:, 4);
x5 = data5(:, 1); pressure5 = data5(:, 4);

% Plot
figure;
plot(x1, pressure1, 'Color', [0 0.447 0.741], 'LineWidth', 1.5); hold on;   % Dark Blue
plot(x2, pressure2, 'Color', [0.85 0.325 0.098], 'LineWidth', 1.5); hold on;   % Dark Red
plot(x3, pressure3, 'Color', [0.301 0.745 0.933], 'LineWidth', 1.5); hold on;   % black
plot(x4, pressure4, 'Color', [0.466 0.674 0.188], 'LineWidth', 1.5); hold on; % Dark Cyan
plot(x5, pressure5, 'LineStyle', '--', 'Color', [0.494 0.184 0.556] , 'LineWidth', 1.5); hold on; % Dark Magenta 
xlabel('x distance (m)');
ylabel('Pressure (Pa)');
title('Pressure vs. x (Horizontal Step)');
legend('Base Resolution', 'x2 Resolution', 'x4 Resolution', 'x8 Resolution', 'x16 Resolution', 'Location', 'best');
grid on;

print('-depsc', 'stepHorizontal.eps');

datasets = {x1, x2, x3, x4, x5};
pressures = {pressure1, pressure2, pressure3, pressure4, pressure5};
labels = {'Base', 'x2', 'x4', 'x8', 'x16'};

for i = 1:5
    x = datasets{i};
    p = pressures{i};
    dpdx = gradient(p, x);
    threshold = 0.1 * max(abs(dpdx));  % You can tune this threshold
    shock_indices = find(abs(dpdx) > threshold);
    shock_x = x(shock_indices);
    
    fprintf('\nShock x-locations (%s Resolution):\n', labels{i});
    disp(shock_x);
end
clc; 
clear; 
% Load both files
data1 = load('topWall_p_T.xy');         % Fewer points
data2 = load('topWall_p_Nx2.xy');   % More points
data3 = load('topWall_p_Nx4.xy');
data4 = load('topWall_p_Nx8.xy');
data5 = load('topWall_p_Nx16.xy');

% Extract pressure (4th column)
pressure1 = data1(:, 4);
pressure2 = data2(:, 4);
pressure3 = data3(:, 4); 
pressure4 = data4(:, 4);  
pressure5 = data5(:, 4); 

% Create time vectors from 0 to 4 seconds
x1 = data1(:, 1);
x2 = data2(:, 1);
x3 = data3(:, 1);
x4 = data4(:, 1);
x5 = data5(:, 1);

% Plot both on the same graph
figure;
plot(x1, pressure1, 'Color', [0 0.447 0.741], 'LineWidth', 1.5); hold on;   % Dark Blue
plot(x2, pressure2, 'Color', [0.85 0.325 0.098], 'LineWidth', 1.5); hold on;   % Dark Red
plot(x3, pressure3, 'Color', [0.301 0.745 0.933], 'LineWidth', 1.5); hold on;   % black
plot(x4, pressure4, 'Color', [0.466 0.674 0.188], 'LineWidth', 1.5); hold on; % Dark Cyan
plot(x5, pressure5, 'LineStyle', '--', 'Color', [0.494 0.184 0.556], 'LineWidth', 1.5); hold on; % Dark Magenta 
xlabel('x distance (m)');
ylabel('Pressure (Pa)');
title('Pressure vs. x (Top Wall)');
legend('Base Resolution', 'x2 Resolution', 'x4 Resolution', 'x8 Resolution', 'x16 Resolution', 'Location', 'best');
grid on;

print('-depsc', 'topWall.eps');

datasets = {x1, x2, x3, x4, x5};
pressures = {pressure1, pressure2, pressure3, pressure4, pressure5};
labels = {'Base', 'x2', 'x4', 'x8', 'x16'};

for i = 1:5
    x = datasets{i};
    p = pressures{i};
    dpdx = gradient(p, x);
    threshold = 0.1 * max(abs(dpdx));  % You can tune this threshold
    shock_indices = find(abs(dpdx) > threshold);
    shock_x = x(shock_indices);
    
    fprintf('\nShock x-locations (%s Resolution):\n', labels{i});
    disp(shock_x);
end
